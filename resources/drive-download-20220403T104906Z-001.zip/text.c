#include"text.h"



text initText()
{ text t ;
  t.pos.x = 600 ;
  t.pos.x = 400;
  //Yellow
  t.textcolor.r=200 ;
  t.textcolor.g=255 ;
  t.textcolor.b= 4 ;
  //Font
  t.font =TTF_OpenFont("FONT.ttf",80) ;

return t ;
}
void displaytext(text t,SDL_Surface * screen)
{
  t.surfacetext = TTF_RenderText_Solid(t.font,"This is the Play menu!",t.textcolor);
    SDL_BlitSurface(t.surfacetext, NULL, screen,&t.pos);


}
