#include "menu.h"
#include "sound.h"


SDL_Event event;
int quit = 0;

int y =0 ;
text t ;
int x ;
void init(){
    if ((SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER | SDL_INIT_AUDIO) != 0))
    printf("Could not initialize SDL: %s.\n", SDL_GetError());

  if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024) == -1)
 printf("%s", Mix_GetError());
  screen = SDL_SetVideoMode(1440, 900, 32,SDL_HWSURFACE | SDL_DOUBLEBUF | SDL_RESIZABLE|SDL_FULLSCREEN);


}

void update(){
  while (SDL_PollEvent( & event)) {
    switch (event.type) {
    case SDL_QUIT:
      quit = 1;
      break;
    case SDL_KEYDOWN:
      onKeyDown(event, &quit);
      switch(event.key.keysym.sym){
        case SDLK_p:
                    if(Mix_PausedMusic() == 1)//Si la musique est en pause
                    {
                        Mix_ResumeMusic(); //Reprendre la musique
                    }
                    else
                    {
                        Mix_PauseMusic(); //Mettre en pause la musique
                    }

                    break;
                case SDLK_BACKSPACE:
                    Mix_RewindMusic(); //Revient au début de la musique
                    break;
                case SDLK_ESCAPE:
                    Mix_HaltMusic(); //Arrête la musique
                    break;
                    case SDLK_f :
                    x= test() ;
                    if(x== 2)
                    SDL_WM_ToggleFullScreen(screen) ;
                    break ;






      }
      break;
    case SDL_MOUSEMOTION:
      onMouseHover(event.motion.x, event.motion.y);
      break;
    case SDL_MOUSEBUTTONUP:
      onButtonActive(&quit);
x= test() ;
if((x==2)&&(isMouseOverButton(event.motion.x,event.motion.y,475,550,225,80)))
SDL_WM_ToggleFullScreen(screen) ;
      break;
    }
  }
}

void end(){
  killMusic();
Mix_FreeMusic(musics);
  SDL_Quit();

}


int main(int argc, char ** argv) {
  init();
text t ;
background2 b ;
t= initText() ; //INI TEXT
b = i() ; // INI BIRD
int u=64 ;
musics =Mix_LoadMUS("test.mp3") ; // INI Music
Mix_PlayMusic(musics,-1);
//....................
home_page();
display_menu(screen);
displaytext(t,screen) ;
SDL_Flip(screen) ;

//While Loop
 while (!quit){
   displaytext(t,screen) ;
display_bird(b,screen);
    animate_bird(&b,40) ;

 SDL_Flip(screen);
SDL_Delay(200);
    update();
  if(event.key.keysym.sym == SDLK_a)
  {u=u-10 ;Mix_VolumeMusic(u);
  u=Mix_VolumeMusic(-1);}
  else if(event.key.keysym.sym == SDLK_b){u+=10 ;Mix_VolumeMusic(u);
  u=Mix_VolumeMusic(-1) ;} 
    update_menu(screen);

  }
  end();
}
