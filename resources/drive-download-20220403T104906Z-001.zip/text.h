#ifndef text_H
#define text_h
#include <SDL/SDL_ttf.h>
#include <SDL/SDL.h>


typedef struct {
SDL_Rect pos ;
TTF_Font *font ;
SDL_Surface * surfacetext  ;
SDL_Color textcolor ;
char text[20] ;
} text ;

text initText() ;
void displaytext(text t,SDL_Surface * screen) ;



#endif
