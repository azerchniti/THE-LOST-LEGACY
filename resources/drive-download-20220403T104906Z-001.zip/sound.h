#ifndef sound_H
#define sound_h
#include <SDL/SDL.h>

#include <SDL/SDL_image.h>

#include <SDL/SDL_mixer.h>

#include <SDL/SDL_ttf.h>

#include <stdlib.h>

#include <string.h>

#include <stdio.h>


Mix_Chunk * music;

void initSound(char * path);
void killMusic();

#endif
